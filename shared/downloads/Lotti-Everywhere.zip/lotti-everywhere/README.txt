LOTTI EVERYWHERE - Lotti on your other tabs (Chrome or Edge)

Install (about a minute):
1. Unzip this folder somewhere you will keep it (for example Documents).
2. Open  chrome://extensions  (Edge: edge://extensions) and turn on "Developer mode".
3. Click "Load unpacked" and pick the unzipped "lotti-everywhere" folder.
4. Open Zendesk, Jira, the CRM or the Help Center: a green Lotti robot appears in the bottom-right corner.

Use:
- Click the robot, press Alt+L, or click the toolbar icon: Lotti opens in a small window next to your tab.
- The first time, sign in to the Lofty Support Portal in that window (like any website). After that it remembers you.
- Drag the robot anywhere. Click the x on it to hide it on a site you do not want it on.
- Paste or attach a screenshot in Lotti and she reads it.

Notes:
- Lotti's answers only work on the Lofty network or VPN.
- The robot only appears on work sites (Zendesk, Atlassian, lofty.com, HubSpot, SharePoint, Teams, Outlook). It never reads or changes the page you are on.
- To update, replace the folder contents with the new version and click the reload icon on chrome://extensions.
- To remove it: chrome://extensions -> Remove.
